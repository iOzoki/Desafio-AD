Planilha com resultados
#
https://docs.google.com/spreadsheets/d/1DwZQfk9ikrAbP1RYQjRkif46QsFEfG-s_TJXaVRd-4g/edit?usp=sharing
